const lovish = require("./second");

console.log("Hello world", lovish)
