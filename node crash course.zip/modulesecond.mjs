export function simple(){
    console.log("Simple is Complex")
    return 45
}

export default function simple2(){
    console.log("Simple2 is Complex")
}

// module.exports = simple;

