// import {simple, simple2} from "./modulesecond.mjs"
import * as a2 from "./modulesecond.mjs"
// const simple2 = require("./modulesecond.mjs");

// simple23()
console.log(a2.simple())