// (function(exports, require, module, __filename, __dirname){

harry = {
    name: "Harry",
    favNum: 36,
    developer: true
}
// console.log(exports, require, module, __filename, __dirname)
module.exports = harry;
    
// })
